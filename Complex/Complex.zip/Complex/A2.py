from A1 import ComplexNumber
import numbers
import math

class Matrix:

    def __init__(self, matrix) -> None:
        self.matrix = matrix

    def toString(self):
        for i in range(3):
            for j in range(3):
                c = self.matrix[i][j]
                print(f'{c.toString()}')
            print(f'\n')
                
    # matrix multiplication
    def matrixMultiply(self, other):
        mat = []
        for i in range(3):
            # generate new list
            rows = []
            for j in range(3):
                res = self.matrix[i][j].multiply(other.matrix[j][i])
                rows.append(res)
            mat.append(rows)    
        return Matrix(mat)        

    # vector x matrix multiplication
    def vectorMultiply(self, vector):
        res = []
        for i in range(3):
            row = ComplexNumber()
            for j in range(3):
                # dot product
                c = self.matrix[i][j]
                
                v = vector.matrix[j]
                row = v.multiply(c)
                row.add(v.multiply(c))
            res.append(row)
            print(row.toString())
        return Matrix(res)

    # square matrix and tells if it is hermitian
    def isHermitian(self) -> bool:
        pass

    # square matrix and tells if it is unitary
    def isUnitary(self) -> bool:
        pass

    # two matrices and constructs their tensor product
    def tensorProduct(MatrixA, MatrixB):
        pass


# construct a matrix of in a ComplexNumber space 
matrix1 = Matrix([
    [ComplexNumber(3, 2), ComplexNumber(0, 0), ComplexNumber(5, -6)],
    [ComplexNumber(1, 0), ComplexNumber(4, 2), ComplexNumber(0, 1)],
    [ComplexNumber(4, -1), ComplexNumber(0, 0), ComplexNumber(4, 0)],
    ])

matrix2 = Matrix([
    [ComplexNumber(5, 1), ComplexNumber(2, -1), ComplexNumber(5, -6)],
    [ComplexNumber(1, 1), ComplexNumber(4, 5), ComplexNumber(2, 1)],
    [ComplexNumber(7, -4), ComplexNumber(2, 7), ComplexNumber(1, 1)],
    ])

matrix4 = [
    [ComplexNumber(5, 0), ComplexNumber(4, 5), ComplexNumber(6, -16)],
    [ComplexNumber(4, -5), ComplexNumber(4, 5), ComplexNumber(7, 0)],
    [ComplexNumber(6, 16), ComplexNumber(7, 0), ComplexNumber(-2, 0)],
    ]

matrix6 = [
    [ComplexNumber(1/math.sqrt(3), 0), ComplexNumber(1/math.sqrt(3), 5), ComplexNumber(1/math.sqrt(3), -16)],
    [ComplexNumber(1/math.sqrt(2), 0), ComplexNumber(0, 0), ComplexNumber(-1/math.sqrt(2))],
    [ComplexNumber(1/math.sqrt(6), 0), ComplexNumber(2/math.sqrt(6), 0), ComplexNumber(1/math.sqrt(6), 0)],
    ]

matrix3 = Matrix([
    [ComplexNumber(5, 0), ComplexNumber(2, -1)],
    [ComplexNumber(0, 0), ComplexNumber(4, 5)]
])

vect1 = Matrix([ComplexNumber(5, 1), ComplexNumber(3, 1), ComplexNumber(-7, 1)])
vect2 = Matrix([ComplexNumber(6, 1), ComplexNumber(6, 1), ComplexNumber(0, 1)])

vect4 = [ComplexNumber(6, 1), ComplexNumber(6, 1), ComplexNumber(0, 1)]
vect5 = [ComplexNumber(5, 1), ComplexNumber(3, 1), ComplexNumber(-7, 1)]

print("Matrix Multiplication: \n")
matrix3 = matrix1.matrixMultiply(matrix2)
matrix3.toString()
print("Vector Matrix Multiplication: \n")
vect3 = matrix2.vectorMultiply(vect1)

   # two complex vectors of length n and calculates their inner product
def innerProduct(vector1, vector2):
    print("innerProduct of two vectors: \n")
    result = ComplexNumber()
    for i in range(3):
        v1 = vector1[i]
        v2 = vector2[i].getCConjugate()
        v3 = v1.multiply(v2)
        print(v3.toString())
        result.add(v1.multiply(v2))
    print(result.toString())
       # calculate the norm of a complex vector
def norm(vector1):
    print("norm of a complex vector: \n")
    result = ComplexNumber()
    for i in range(2):
        v1 = vector1[i]
        print(v1.pow2().toString())
        result.add(v1.pow2())
        print(result.sqrt().toString())

 # calculates the distance of two given complex vectors
def distance(vector1, vector2):
    print("distance function: ")
    vector = []
    for i in range(3):
        v1 = vector1[i]
        v2 = vector2[i]
        v3 = v1.sub(v2)
        print(v3.sqrt().toString())

def transpose(matrix):
    return [list(col) for col in zip(*matrix)]
    # square matrix and tells if it is hermitian
def isHermitian(matrix) -> bool:
    print("\nisHermitian: ")
    for i in range(3):
        for j in range(3):
            if i != j:
                c = matrix[i][j]
                tc = matrix[j][i].getCConjugate()
                print(c.compare(tc))

    # square matrix and tells if it is unitary
def isUnitary(matrix) -> bool:
    print("\nisUnitary: , once iteration recieves a flase output, the matrix is delcare NOT unitart")
    for i in range(3):
            for j in range(3):
                if i != j:
                    c = matrix[i][j]
                    tc = matrix[j][i].getCConjugate()

                    c2 = c.multiply(tc)
                    print(c2.compare(tc))

    

    # two matrices and constructs their tensor product
def tensorProduct(va, vb):
    print("\t TensorProduct: ")
    tensorProduct = []
    for i in range(len(va)):
        rows = []
        for j in range(len(vb)):
            v1 = va[i].multiply(vb[j])
            print(v1.toString())
            rows.append(v1)
        tensorProduct.append(rows)



innerProduct(vect4, vect5)
norm(vect4)
distance(vect4, vect5)
isHermitian(matrix4) 
isUnitary(matrix6)
tensorProduct(vect4, vect5)

